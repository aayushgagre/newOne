package com.cg.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.services.OrderServices;

@CrossOrigin("http://localhost:4200")
@RestController
@RequestMapping(value = "/capstore")
public class PlacedController {

	@Autowired
	OrderServices service;

	@GetMapping(value = "/placingorder/{userId}")
	public String placeOrder(@PathVariable int userId) {
		return service.checkProducts(userId);
	}

	@PutMapping(value = "/payment/{modeOfPurchase}/{userId}")
	public boolean getPayment(@PathVariable int userId, @PathVariable String modeOfPurchase) {
		return service.updateInventory(userId, modeOfPurchase);
	}

}
