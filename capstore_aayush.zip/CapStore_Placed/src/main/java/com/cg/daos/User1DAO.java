package com.cg.daos;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cg.bean.User1;

@Repository
public interface User1DAO extends JpaRepository<User1, Integer>{

	public User1 findByuserId(int userId);
}
